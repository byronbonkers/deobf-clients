// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.item;

public class ItemSimpleFoiled extends Item
{
    private static final String __OBFID = "CL_00000065";
    
    @Override
    public boolean hasEffect(final ItemStack stack) {
        return true;
    }
}
