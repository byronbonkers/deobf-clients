// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.inventory;

public interface IInvBasic
{
    void onInventoryChanged(final InventoryBasic p0);
}
