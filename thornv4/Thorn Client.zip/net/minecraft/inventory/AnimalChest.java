// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.inventory;

import net.minecraft.util.IChatComponent;

public class AnimalChest extends InventoryBasic
{
    private static final String __OBFID = "CL_00001731";
    
    public AnimalChest(final String p_i1796_1_, final int p_i1796_2_) {
        super(p_i1796_1_, false, p_i1796_2_);
    }
    
    public AnimalChest(final IChatComponent p_i45808_1_, final int p_i45808_2_) {
        super(p_i45808_1_, p_i45808_2_);
    }
}
