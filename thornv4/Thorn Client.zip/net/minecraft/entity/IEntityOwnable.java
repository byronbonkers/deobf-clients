// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.entity;

public interface IEntityOwnable
{
    String func_152113_b();
    
    Entity getOwner();
}
