// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.entity;

import net.minecraft.entity.passive.IAnimals;

public interface INpc extends IAnimals
{
}
