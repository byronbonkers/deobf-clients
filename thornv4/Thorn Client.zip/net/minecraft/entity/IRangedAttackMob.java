// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.entity;

public interface IRangedAttackMob
{
    void attackEntityWithRangedAttack(final EntityLivingBase p0, final float p1);
}
