// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.entity;

public interface IProjectile
{
    void setThrowableHeading(final double p0, final double p1, final double p2, final float p3, final float p4);
}
