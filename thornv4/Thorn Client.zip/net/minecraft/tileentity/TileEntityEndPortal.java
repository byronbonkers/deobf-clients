// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.tileentity;

public class TileEntityEndPortal extends TileEntity
{
    private static final String __OBFID = "CL_00000365";
}
