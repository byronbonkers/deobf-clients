// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.nbt;

public class NBTException extends Exception
{
    private static final String __OBFID = "CL_00001231";
    
    public NBTException(final String p_i45136_1_) {
        super(p_i45136_1_);
    }
}
