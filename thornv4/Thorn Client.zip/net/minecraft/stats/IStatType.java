// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.stats;

public interface IStatType
{
    String format(final int p0);
}
