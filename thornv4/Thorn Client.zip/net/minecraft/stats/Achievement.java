// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.stats;

import net.minecraft.util.StatCollector;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class Achievement extends StatBase
{
    public final int displayColumn;
    public final int displayRow;
    public final Achievement parentAchievement;
    private final String achievementDescription;
    private IStatStringFormat statStringFormatter;
    public final ItemStack theItemStack;
    private boolean isSpecial;
    private static final String __OBFID = "CL_00001466";
    
    public Achievement(final String p_i46327_1_, final String p_i46327_2_, final int p_i46327_3_, final int p_i46327_4_, final Item p_i46327_5_, final Achievement p_i46327_6_) {
        this(p_i46327_1_, p_i46327_2_, p_i46327_3_, p_i46327_4_, new ItemStack(p_i46327_5_), p_i46327_6_);
    }
    
    public Achievement(final String p_i45301_1_, final String p_i45301_2_, final int p_i45301_3_, final int p_i45301_4_, final Block p_i45301_5_, final Achievement p_i45301_6_) {
        this(p_i45301_1_, p_i45301_2_, p_i45301_3_, p_i45301_4_, new ItemStack(p_i45301_5_), p_i45301_6_);
    }
    
    public Achievement(final String p_i45302_1_, final String p_i45302_2_, final int p_i45302_3_, final int p_i45302_4_, final ItemStack p_i45302_5_, final Achievement p_i45302_6_) {
        super(p_i45302_1_, new ChatComponentTranslation("achievement." + p_i45302_2_, new Object[0]));
        this.theItemStack = p_i45302_5_;
        this.achievementDescription = "achievement." + p_i45302_2_ + ".desc";
        this.displayColumn = p_i45302_3_;
        this.displayRow = p_i45302_4_;
        if (p_i45302_3_ < AchievementList.minDisplayColumn) {
            AchievementList.minDisplayColumn = p_i45302_3_;
        }
        if (p_i45302_4_ < AchievementList.minDisplayRow) {
            AchievementList.minDisplayRow = p_i45302_4_;
        }
        if (p_i45302_3_ > AchievementList.maxDisplayColumn) {
            AchievementList.maxDisplayColumn = p_i45302_3_;
        }
        if (p_i45302_4_ > AchievementList.maxDisplayRow) {
            AchievementList.maxDisplayRow = p_i45302_4_;
        }
        this.parentAchievement = p_i45302_6_;
    }
    
    public Achievement func_180789_a() {
        this.isIndependent = true;
        return this;
    }
    
    public Achievement setSpecial() {
        this.isSpecial = true;
        return this;
    }
    
    public Achievement func_180788_c() {
        super.registerStat();
        AchievementList.achievementList.add(this);
        return this;
    }
    
    @Override
    public boolean isAchievement() {
        return true;
    }
    
    @Override
    public IChatComponent getStatName() {
        final IChatComponent var1 = super.getStatName();
        var1.getChatStyle().setColor(this.getSpecial() ? EnumChatFormatting.DARK_PURPLE : EnumChatFormatting.GREEN);
        return var1;
    }
    
    public Achievement func_180787_a(final Class p_180787_1_) {
        return (Achievement)super.func_150953_b(p_180787_1_);
    }
    
    public String getDescription() {
        return (this.statStringFormatter != null) ? this.statStringFormatter.formatString(StatCollector.translateToLocal(this.achievementDescription)) : StatCollector.translateToLocal(this.achievementDescription);
    }
    
    public Achievement setStatStringFormatter(final IStatStringFormat p_75988_1_) {
        this.statStringFormatter = p_75988_1_;
        return this;
    }
    
    public boolean getSpecial() {
        return this.isSpecial;
    }
    
    @Override
    public StatBase func_150953_b(final Class p_150953_1_) {
        return this.func_180787_a(p_150953_1_);
    }
    
    @Override
    public StatBase registerStat() {
        return this.func_180788_c();
    }
    
    @Override
    public StatBase initIndependentStat() {
        return this.func_180789_a();
    }
}
