// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.stats;

public interface IStatStringFormat
{
    String formatString(final String p0);
}
