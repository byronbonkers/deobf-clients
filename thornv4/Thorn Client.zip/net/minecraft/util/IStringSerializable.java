// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.util;

public interface IStringSerializable
{
    String getName();
}
