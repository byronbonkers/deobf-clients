// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.util;

public class MovementInput
{
    public float moveStrafe;
    public float moveForward;
    public boolean jump;
    public boolean sneak;
    private static final String __OBFID = "CL_00000936";
    
    public void updatePlayerMoveState() {
    }
}
