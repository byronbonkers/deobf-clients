// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.world;

public class MinecraftException extends Exception
{
    private static final String __OBFID = "CL_00000145";
    
    public MinecraftException(final String msg) {
        super(msg);
    }
}
