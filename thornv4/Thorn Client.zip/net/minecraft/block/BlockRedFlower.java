// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.block;

public class BlockRedFlower extends BlockFlower
{
    private static final String __OBFID = "CL_00002073";
    
    @Override
    public EnumFlowerColor func_176495_j() {
        return EnumFlowerColor.RED;
    }
}
