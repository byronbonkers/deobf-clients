// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.block;

public class BlockHalfStoneSlab extends BlockStoneSlab
{
    private static final String __OBFID = "CL_00002108";
    
    @Override
    public boolean isDouble() {
        return false;
    }
}
