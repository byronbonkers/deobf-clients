// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.command;

public class WrongUsageException extends SyntaxErrorException
{
    private static final String __OBFID = "CL_00001192";
    
    public WrongUsageException(final String p_i1364_1_, final Object... p_i1364_2_) {
        super(p_i1364_1_, p_i1364_2_);
    }
}
