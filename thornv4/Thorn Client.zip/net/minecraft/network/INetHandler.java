// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.network;

import net.minecraft.util.IChatComponent;

public interface INetHandler
{
    void onDisconnect(final IChatComponent p0);
}
